# Chatbot_using_NLP_AICTE_Cycle4
Training for the project on Implementation of Chatbot using NLP

To run streamlit use the command as
# streamlit run chatbot.py
The above command has to be run in command prompt by navigating to the folder or using VSC terminal or Terminal of Mac. But navigating to the folder where you have script is important.
